import React, { useContext } from 'react';
import { Checkbox, Button } from 'antd';
import TableContext from '../../context';
import './index.less';

interface ColumnSettingProps {}

const ColumnSetting: React.FC<ColumnSettingProps> = () => {
  const { columns, selectedDataIndex, setSelectedDataIndex } = useContext(
    TableContext,
  );

  return (
    <div className="uniubi-pro-table-toolbar-column-setting">
      <div className="uniubi-pro-table-toolbar-column-setting-header">
        <span className="uniubi-pro-table-toolbar-column-setting-header-text">
          列展示
        </span>
        <Button
          type="link"
          onClick={() => {
            setSelectedDataIndex(columns.map(item => item.dataIndex));
          }}
        >
          重置
        </Button>
      </div>
      <div className="uniubi-pro-table-toolbar-column-setting-body">
        <Checkbox.Group
          options={columns.map(item => ({
            label: item.title,
            value: item.dataIndex,
          }))}
          value={selectedDataIndex}
          onChange={checkedValue =>
            setSelectedDataIndex(checkedValue as string[])
          }
        />
      </div>
    </div>
  );
};

export default ColumnSetting;
