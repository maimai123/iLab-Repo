// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from '/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/~demos/:uuid",
    "layout": false,
    "wrappers": [require('../dumi/layout').default],
    "component": ((props) => {
        const React = require('react');
        const { default: getDemoRenderArgs } = require('/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/node_modules/@umijs/preset-dumi/lib/plugins/features/demo/getDemoRenderArgs');
        const { default: Previewer } = require('dumi-theme-default/es/builtins/Previewer.js');
        const { usePrefersColor, context } = require('dumi/theme');

        
      const { demos } = React.useContext(context);
      const [renderArgs, setRenderArgs] = React.useState([]);

      // update render args when props changed
      React.useLayoutEffect(() => {
        setRenderArgs(getDemoRenderArgs(props, demos));
      }, [props.match.params.uuid, props.location.query.wrapper, props.location.query.capture]);

      // for listen prefers-color-schema media change in demo single route
      usePrefersColor();

      switch (renderArgs.length) {
        case 1:
          // render demo directly
          return renderArgs[0];

        case 2:
          // render demo with previewer
          return React.createElement(
            Previewer,
            renderArgs[0],
            renderArgs[1],
          );

        default:
          return `Demo ${props.match.params.uuid} not found :(`;
      }
    
        })
  },
  {
    "path": "/_demos/:uuid",
    "redirect": "/~demos/:uuid"
  },
  {
    "__dumiRoot": true,
    "layout": false,
    "path": "/",
    "wrappers": [require('../dumi/layout').default, require('/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/node_modules/dumi-theme-default/es/layout.js').default],
    "routes": [
      {
        "path": "/ellipsis-line",
        "component": require('/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/src/EllipsisLine/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/EllipsisLine/index.md",
          "updatedTime": 1644828266210,
          "componentName": "EllipsisLine",
          "slugs": [
            {
              "depth": 2,
              "value": "EllipsisLine",
              "heading": "ellipsisline"
            }
          ],
          "title": "EllipsisLine",
          "hasPreviewer": true,
          "group": {
            "path": "/ellipsis-line",
            "title": "EllipsisLine"
          }
        },
        "title": "EllipsisLine - iLab-lib"
      },
      {
        "path": "/pro-table",
        "component": require('/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/src/ProTable/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/ProTable/index.md",
          "updatedTime": 1644983200271,
          "componentName": "ProTable",
          "group": {
            "title": "ProTable 组件",
            "order": null,
            "__fallback": true,
            "path": "/pro-table"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "ProTable 组件",
              "heading": "protable-组件"
            },
            {
              "depth": 3,
              "value": "基础用法",
              "heading": "基础用法"
            },
            {
              "depth": 3,
              "value": "API",
              "heading": "api"
            },
            {
              "depth": 4,
              "value": "ProTable",
              "heading": "protable"
            },
            {
              "depth": 4,
              "value": "ProColumn 列定义",
              "heading": "procolumn-列定义"
            },
            {
              "depth": 4,
              "value": "ValueEnum 定义",
              "heading": "valueenum-定义"
            },
            {
              "depth": 4,
              "value": "toolbar Props 定义",
              "heading": "toolbar-props-定义"
            },
            {
              "depth": 4,
              "value": "ActionRef 手动触发",
              "heading": "actionref-手动触发"
            }
          ],
          "title": "ProTable 组件",
          "hasPreviewer": true
        },
        "title": "ProTable 组件 - iLab-lib"
      },
      {
        "path": "/table-filter",
        "component": require('/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/src/TableFilter/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "src/TableFilter/index.md",
          "updatedTime": 1644990195636,
          "componentName": "TableFilter",
          "group": {
            "title": "TableFilter 组件",
            "order": null,
            "__fallback": true,
            "path": "/table-filter"
          },
          "slugs": [
            {
              "depth": 2,
              "value": "TableFilter 组件",
              "heading": "tablefilter-组件"
            },
            {
              "depth": 3,
              "value": "基础用法",
              "heading": "基础用法"
            },
            {
              "depth": 3,
              "value": "API",
              "heading": "api"
            },
            {
              "depth": 4,
              "value": "TableFilter",
              "heading": "tablefilter"
            },
            {
              "depth": 4,
              "value": "IField",
              "heading": "ifield"
            },
            {
              "depth": 4,
              "value": "ActionRef 手动触发",
              "heading": "actionref-手动触发"
            }
          ],
          "title": "TableFilter 组件",
          "hasPreviewer": true
        },
        "title": "TableFilter 组件 - iLab-lib"
      },
      {
        "path": "/",
        "component": require('/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/docs/index.md').default,
        "exact": true,
        "meta": {
          "filePath": "docs/index.md",
          "updatedTime": 1644828367042,
          "slugs": [
            {
              "depth": 2,
              "value": "Hello iLab-lib!",
              "heading": "hello-ilab-lib"
            }
          ],
          "title": "Hello iLab-lib!"
        },
        "title": "Hello iLab-lib! - iLab-lib"
      }
    ],
    "title": "iLab-lib",
    "component": (props) => props.children
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
