// @ts-nocheck
import React from 'react';
import { dynamic } from 'dumi';

export default {
  'EllipsisLine-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _react = _interopRequireDefault(require("react"));

  var _iLabLib = require("iLab-lib");

  var _default = function _default() {
    return /*#__PURE__*/_react["default"].createElement("div", {
      style: {
        width: 500,
        border: '1px solid #bdbdbd',
        padding: 16
      }
    }, /*#__PURE__*/_react["default"].createElement(_iLabLib.EllipsisLine, {
      row: 3,
      content: "\u4E94\u767E\u91CC\u6EC7\u6C60\uFF0C\u5954\u6765\u773C\u5E95\uFF0C\u62AB\u895F\u5CB8\u5E3B\uFF0C\u559C\u832B\u832B\u7A7A\u9614\u65E0\u8FB9\u3002\u770B\u4E1C\u9AA7\u795E\u9A8F\uFF0C\u897F\u7FE5\u7075\u4EEA\uFF0C\u5317\u8D70\u873F\u8712\uFF0C\u5357\u7FD4\u7F1F\u7D20\u3002\u9AD8\u4EBA\u97F5\u58EB\uFF0C\u4F55\u59A8\u9009\u80DC\u767B\u4E34\u3002\u8D81\u87F9\u5C7F\u87BA\u6D32\uFF0C\u68B3\u88F9\u5C31\u98CE\u9B1F\u96FE\u9B13\uFF1B\u66F4\u82F9\u5929\u82C7\u5730\uFF0C\u70B9\u7F00\u4E9B\u7FE0\u7FBD\u4E39\u971E\uFF0C\u83AB\u8F9C\u8D1F\u56DB\u56F4\u9999\u7A3B\uFF0C\u4E07\u9877\u6674\u6C99\uFF0C\u4E5D\u590F\u8299\u84C9\uFF0C\u4E09\u6625\u6768\u67F3\u3002 \u6570\u5343\u5E74\u5F80\u4E8B\uFF0C\u6CE8\u5230\u5FC3\u5934\uFF0C\u628A\u9152\u51CC\u865A\uFF0C\u53F9\u6EDA\u6EDA\u82F1\u96C4\u8C01\u5728\u3002\u60F3\u6C49\u4E60\u697C\u8239\uFF0C\u5510\u6807\u94C1\u67F1\uFF0C\u5B8B\u6325\u7389\u65A7\uFF0C\u5143\u8DE8\u9769\u56CA\u3002\u4F1F\u70C8\u4E30\u529F\uFF0C\u8D39\u5C3D\u79FB\u5C71\u5FC3\u529B\u3002\u5C3D\u73E0\u5E18\u753B\u680B\uFF0C\u5377\u4E0D\u53CA\u66AE\u96E8\u671D\u4E91\uFF1B\u4FBF\u65AD\u78A3\u6B8B\u7891\uFF0C\u90FD\u4ED8\u4E0E\u82CD\u70DF\u843D\u7167\u3002\u53EA\u8D62\u5F97\u51E0\u6775\u758F\u949F\uFF0C\u534A\u6C5F\u6E14\u706B\uFF0C\u4E24\u884C\u79CB\u96C1\uFF0C\u4E00\u6795\u6E05\u971C"
    }));
  };

  return _react["default"].createElement(_default);
},
    previewerProps: {"sources":{"_":{"tsx":"import React from 'react';\nimport { EllipsisLine } from 'iLab-lib';\n\nexport default () => <div style={{ width: 500, border: '1px solid #bdbdbd', padding: 16 }}><EllipsisLine row={3} content=\"五百里滇池，奔来眼底，披襟岸帻，喜茫茫空阔无边。看东骧神骏，西翥灵仪，北走蜿蜒，南翔缟素。高人韵士，何妨选胜登临。趁蟹屿螺洲，梳裹就风鬟雾鬓；更苹天苇地，点缀些翠羽丹霞，莫辜负四围香稻，万顷晴沙，九夏芙蓉，三春杨柳。 数千年往事，注到心头，把酒凌虚，叹滚滚英雄谁在。想汉习楼船，唐标铁柱，宋挥玉斧，元跨革囊。伟烈丰功，费尽移山心力。尽珠帘画栋，卷不及暮雨朝云；便断碣残碑，都付与苍烟落照。只赢得几杵疏钟，半江渔火，两行秋雁，一枕清霜\" /></div>;"}},"dependencies":{"react":{"version":"17.0.2"},"iLab-lib":{"version":"1.0.0"}},"componentName":"EllipsisLine","identifier":"EllipsisLine-demo"},
  },
  'ProTable-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _react = _interopRequireWildcard(require("react"));

  var _iLabLib = require("iLab-lib");

  var _antd = require("antd");

  var _moment = _interopRequireDefault(require("moment"));

  function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }

  function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }

  var _default = function _default() {
    var columns = [{
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
      search: false,
      sorter: function sorter(a, b) {
        return a.id - b.id;
      }
    }, {
      title: 'DateRange',
      dataIndex: 'dateRange',
      key: 'dateRange',
      search: true,
      valueType: 'dateRange'
    }, {
      title: 'PersonName',
      dataIndex: 'personName',
      key: 'personName',
      search: true,
      searchProps: {
        placeholder: '请输入 Name'
      },
      render: function render(text) {
        return /*#__PURE__*/_react["default"].createElement("a", null, text);
      },
      sorter: function sorter(a, b) {
        return a.personName.length - b.personName.length;
      }
    }, {
      title: 'Sex',
      dataIndex: 'sex',
      key: 'sex',
      search: true,
      valueType: 'select',
      valueEnum: new Map([[1, 'male'], [2, 'female']]),
      searchProps: {
        showSearch: true,
        filterOption: function filterOption(input, option) {
          return option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0;
        }
      }
    }, {
      title: 'Status',
      dataIndex: 'status',
      key: 'status',
      search: true,
      valueType: 'select',
      valueEnum: new Map([[1, {
        text: 'online',
        status: 'success'
      }], [2, {
        text: 'offline',
        status: 'error'
      }]])
    }, {
      title: 'Tree',
      dataIndex: 'tree',
      key: 'tree',
      search: true,
      valueType: 'treeSelect',
      searchProps: {
        treeData: [{
          title: 'Node1',
          value: '0-0',
          children: [{
            title: 'Child Node1',
            value: '0-0-1'
          }, {
            title: 'Child Node2',
            value: '0-0-2'
          }]
        }, {
          title: 'Node2',
          value: '0-1'
        }]
      }
    }, {
      title: 'Address',
      dataIndex: 'address',
      key: 'address'
    }, {
      title: 'Tags',
      key: 'tags',
      dataIndex: 'tags',
      render: function render(tags) {
        return /*#__PURE__*/_react["default"].createElement(_react["default"].Fragment, null, tags.map(function (tag) {
          var color = tag.length > 5 ? 'geekblue' : 'green';

          if (tag === 'loser') {
            color = 'volcano';
          }

          return /*#__PURE__*/_react["default"].createElement(_antd.Tag, {
            color: color,
            key: tag
          }, tag.toUpperCase());
        }));
      }
    }, {
      title: 'Area',
      dataIndex: 'area',
      key: 'area',
      search: true,
      valueType: 'cascader',
      searchProps: {
        options: [{
          value: 'zhejiang',
          label: 'Zhejiang',
          isLeaf: false
        }, {
          value: 'jiangsu',
          label: 'Jiangsu',
          isLeaf: false
        }]
      }
    }];
    var dataSource = new Array(40).fill('').map(function (_, index) {
      return {
        id: index,
        personName: 'name',
        sex: 1,
        status: 1,
        address: 'address',
        tags: ['tag1', 'tag2'],
        area: ['zhejiang']
      };
    });
    var toolbar = {
      actions: [/*#__PURE__*/_react["default"].createElement(_antd.Button, {
        onClick: function onClick() {
          actionRef.current.reload();
        },
        key: "reload"
      }, "reload"), /*#__PURE__*/_react["default"].createElement(_antd.Button, {
        onClick: function onClick() {
          console.log(actionRef.current.getFilterValue());
        },
        key: "getFilterValue"
      }, "getFilterValue"), /*#__PURE__*/_react["default"].createElement(_antd.Button, {
        onClick: function onClick() {
          actionRef.current.setFilterValue({
            personName: 'PersonName'
          });
        },
        key: "setFilterValue"
      }, "setFieldsValue"), /*#__PURE__*/_react["default"].createElement(_antd.Button, {
        onClick: function onClick() {
          console.log(actionRef.current.resetFilter());
        },
        key: "resetFilter"
      }, "resetFilter")],
      options: {
        refresh: true,
        columnSetting: true
      },
      slot: [/*#__PURE__*/_react["default"].createElement(_antd.Input, {
        key: "slot-input",
        placeholder: "slot"
      })]
    };
    var actionRef = (0, _react.useRef)();
    return /*#__PURE__*/_react["default"].createElement(_iLabLib.ProTable, {
      actionRef: actionRef,
      columns: columns,
      dataSource: dataSource,
      rowKey: "id",
      toolbar: toolbar,
      formProps: {
        initialValues: {
          dateRange: [(0, _moment["default"])(), (0, _moment["default"])()]
        }
      }
    });
  };

  return _react["default"].createElement(_default);
},
    previewerProps: {"sources":{"_":{"tsx":"import React, { useRef } from 'react';\nimport { ProTable } from 'iLab-lib';\nimport { ActionType } from 'iLab-lib/lib/ProTable';\nimport { Tag, Button, Space, Input } from 'antd';\nimport moment from 'moment';\n\nexport default () => {\n  const columns = [\n    {\n      title: 'ID',\n      dataIndex: 'id',\n      key: 'id',\n      search: false,\n      sorter: (a, b) => a.id - b.id,\n    },\n    {\n      title: 'DateRange',\n      dataIndex: 'dateRange',\n      key: 'dateRange',\n      search: true,\n      valueType: 'dateRange',\n    },\n    {\n      title: 'PersonName',\n      dataIndex: 'personName',\n      key: 'personName',\n      search: true,\n      searchProps: {\n        placeholder: '请输入 Name',\n      },\n      render: text => <a>{text}</a>,\n      sorter: (a, b) => a.personName.length - b.personName.length,\n    },\n    {\n      title: 'Sex',\n      dataIndex: 'sex',\n      key: 'sex',\n      search: true,\n      valueType: 'select',\n      valueEnum: new Map([\n        [1, 'male'],\n        [2, 'female'],\n      ]),\n      searchProps: {\n        showSearch: true,\n        filterOption: (input, option) =>\n          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0,\n      },\n    },\n    {\n      title: 'Status',\n      dataIndex: 'status',\n      key: 'status',\n      search: true,\n      valueType: 'select',\n      valueEnum: new Map([\n        [1, { text: 'online', status: 'success' }],\n        [2, { text: 'offline', status: 'error' }],\n      ]),\n    },\n    {\n      title: 'Tree',\n      dataIndex: 'tree',\n      key: 'tree',\n      search: true,\n      valueType: 'treeSelect',\n      searchProps: {\n        treeData: [\n          {\n            title: 'Node1',\n            value: '0-0',\n            children: [\n              {\n                title: 'Child Node1',\n                value: '0-0-1',\n              },\n              {\n                title: 'Child Node2',\n                value: '0-0-2',\n              },\n            ],\n          },\n          {\n            title: 'Node2',\n            value: '0-1',\n          },\n        ],\n      },\n    },\n    {\n      title: 'Address',\n      dataIndex: 'address',\n      key: 'address',\n    },\n    {\n      title: 'Tags',\n      key: 'tags',\n      dataIndex: 'tags',\n      render: tags => (\n        <>\n          {tags.map(tag => {\n            let color = tag.length > 5 ? 'geekblue' : 'green';\n            if (tag === 'loser') {\n              color = 'volcano';\n            }\n            return (\n              <Tag color={color} key={tag}>\n                {tag.toUpperCase()}\n              </Tag>\n            );\n          })}\n        </>\n      ),\n    },\n    {\n      title: 'Area',\n      dataIndex: 'area',\n      key: 'area',\n      search: true,\n      valueType: 'cascader',\n      searchProps: {\n        options: [\n          {\n            value: 'zhejiang',\n            label: 'Zhejiang',\n            isLeaf: false,\n          },\n          {\n            value: 'jiangsu',\n            label: 'Jiangsu',\n            isLeaf: false,\n          },\n        ],\n      },\n    },\n  ];\n\n  const dataSource = new Array(40).fill('').map((_, index) => ({\n    id: index,\n    personName: 'name',\n    sex: 1,\n    status: 1,\n    address: 'address',\n    tags: ['tag1', 'tag2'],\n    area: ['zhejiang'],\n  }));\n\n  const toolbar = {\n    actions: [\n      <Button\n        onClick={() => {\n          actionRef.current.reload();\n        }}\n        key=\"reload\"\n      >\n        reload\n      </Button>,\n      <Button\n        onClick={() => {\n          console.log(actionRef.current.getFilterValue());\n        }}\n        key=\"getFilterValue\"\n      >\n        getFilterValue\n      </Button>,\n      <Button\n        onClick={() => {\n          actionRef.current.setFilterValue({ personName: 'PersonName' });\n        }}\n        key=\"setFilterValue\"\n      >\n        setFieldsValue\n      </Button>,\n      <Button\n        onClick={() => {\n          console.log(actionRef.current.resetFilter());\n        }}\n        key=\"resetFilter\"\n      >\n        resetFilter\n      </Button>,\n    ],\n    options: {\n      refresh: true,\n      columnSetting: true,\n    },\n    slot: [<Input key=\"slot-input\" placeholder=\"slot\" />],\n  };\n\n  const actionRef = useRef<ActionType>();\n\n  return (\n    <ProTable\n      actionRef={actionRef}\n      columns={columns}\n      dataSource={dataSource}\n      rowKey=\"id\"\n      toolbar={toolbar}\n      formProps={{\n        initialValues: {\n          dateRange: [moment(), moment()],\n        },\n      }}\n    />\n  );\n};"}},"dependencies":{"react":{"version":">=16.9.0"},"iLab-lib":{"version":"1.0.0"},"antd":{"version":"4.18.6","css":"antd/dist/antd.css"},"moment":{"version":"2.29.1"},"react-dom":{"version":">=16.9.0"}},"componentName":"ProTable","identifier":"ProTable-demo"},
  },
  'TableFilter-demo': {
    component: function DumiDemo() {
  var _interopRequireDefault = require("/Users/yuyafei/code/shipu/iLab_repo/packages/iLab-lib/node_modules/@umijs/babel-preset-umi/node_modules/@babel/runtime/helpers/interopRequireDefault");

  var _react = _interopRequireDefault(require("react"));

  var _iLabLib = require("iLab-lib");

  var _default = function _default() {
    var options = [{
      value: 'zhejiang',
      label: 'Zhejiang',
      isLeaf: false
    }, {
      value: 'jiangsu',
      label: 'Jiangsu',
      isLeaf: false
    }];
    var fields = [{
      name: 'field1',
      label: '字段1'
    }, {
      name: 'field2',
      valueType: 'select',
      label: '字段2',
      valueEnum: new Map([[1, 'a'], [2, 'b'], [3, 'c']])
    }, {
      name: 'field3',
      valueType: 'date',
      label: '字段3'
    }, {
      name: 'field4',
      valueType: 'dateRange',
      label: '字段4'
    }, {
      name: 'field5',
      valueType: 'cascader',
      label: '字段5',
      searchProps: {
        options: options
      }
    }, {
      name: 'field6',
      valueType: 'treeSelect',
      label: '字段6',
      searchProps: {
        treeData: [{
          title: 'Node1',
          value: '0-0',
          children: [{
            title: 'Child Node1',
            value: '0-0-1'
          }, {
            title: 'Child Node2',
            value: '0-0-2'
          }]
        }, {
          title: 'Node2',
          value: '0-1'
        }]
      }
    }];
    return /*#__PURE__*/_react["default"].createElement(_iLabLib.TableFilter, {
      fields: fields,
      onSearch: console.log
    });
  };

  return _react["default"].createElement(_default);
},
    previewerProps: {"sources":{"_":{"tsx":"import React from 'react';\nimport { TableFilter } from 'iLab-lib';\n\nexport default () => {\n  const options = [\n    {\n      value: 'zhejiang',\n      label: 'Zhejiang',\n      isLeaf: false,\n    },\n    {\n      value: 'jiangsu',\n      label: 'Jiangsu',\n      isLeaf: false,\n    },\n  ];\n  const fields = [\n    { name: 'field1', label: '字段1' },\n    {\n      name: 'field2',\n      valueType: 'select',\n      label: '字段2',\n      valueEnum: new Map([\n        [1, 'a'],\n        [2, 'b'],\n        [3, 'c'],\n      ]),\n    },\n    { name: 'field3', valueType: 'date', label: '字段3' },\n    { name: 'field4', valueType: 'dateRange', label: '字段4' },\n    {\n      name: 'field5',\n      valueType: 'cascader',\n      label: '字段5',\n      searchProps: {\n        options,\n      },\n    },\n    {\n      name: 'field6',\n      valueType: 'treeSelect',\n      label: '字段6',\n      searchProps: {\n        treeData: [\n          {\n            title: 'Node1',\n            value: '0-0',\n            children: [\n              {\n                title: 'Child Node1',\n                value: '0-0-1',\n              },\n              {\n                title: 'Child Node2',\n                value: '0-0-2',\n              },\n            ],\n          },\n          {\n            title: 'Node2',\n            value: '0-1',\n          },\n        ],\n      },\n    },\n  ];\n\n  return <TableFilter fields={fields} onSearch={console.log} />;\n};"}},"dependencies":{"react":{"version":"17.0.2"},"iLab-lib":{"version":"1.0.0"}},"componentName":"TableFilter","identifier":"TableFilter-demo"},
  },
};
