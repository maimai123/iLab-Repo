import React, { useState, useEffect } from 'react';
import { Form, Row, Col, Space, Button } from 'antd';
import { FormProps, FormItemProps } from 'antd/lib/form';
import { UpOutlined, DownOutlined } from '@ant-design/icons';
import classnames from 'classnames';
import Select from './Select';
import TreeSelect from './TreeSelect';
import Input from './Input';
import DatePicker from './DatePicker';
import DateRangePicker from './DateRangePicker';
import Cascader from './Cascader';
import './index.less';

export type ValueType =
  | 'text'
  | 'select'
  | 'treeSelect'
  | 'date'
  | 'dateRange'
  | 'cascader'
  | 'option';

export interface ActionType {
  getFieldsValue: () => any;
  setFieldsValue: (val: any) => void;
  resetFields: () => void;
}

export interface IField extends FormItemProps {
  name: string;
  valueType?: ValueType;
  valueEnum?: Map<any, any>;
  searchProps?: any; // 透穿给表单项内的组件的 props
  order?: number; // 排序
  show?: boolean; // 是否展示该字段
}

export interface TableFilterProps {
  formProps?: FormProps;
  fields: IField[];
  onSearch: (values: any) => void;
  onReset: () => void;
  className?: string;
  style?: React.CSSProperties;
  actionRef?:
    | React.MutableRefObject<ActionType | undefined>
    | ((actionRef: ActionType) => void);
  mode?: 'fixed' | 'static';
  defaultCollapsed?: boolean;
}

const GUTTER = 16;
const SPAN = 6;
// 收起时展示字段数
const LINE_COUNT = 3;

const TableFilter: React.FC<TableFilterProps> = ({
  formProps,
  fields,
  onSearch,
  onReset,
  className,
  style,
  actionRef,
  mode = 'fixed',
  defaultCollapsed = true,
}) => {
  const [form] = Form.useForm();
  // 是否收起
  const [collapsed, setCollapsed] = useState<boolean>(defaultCollapsed);
  // 是否需要展开收起按钮
  const needCollapsedButton = fields.length > LINE_COUNT;

  useEffect(() => {
    const userAction: ActionType = {
      getFieldsValue: () => form.getFieldsValue(),
      setFieldsValue: val => form.setFieldsValue(val),
      resetFields: () => form.resetFields(),
    };

    if (actionRef && typeof actionRef !== 'function') {
      actionRef.current = userAction;
    }
  }, []);

  const matchItem = (field: IField) => {
    switch (field.valueType) {
      case 'select':
        return field.valueEnum ? (
          <Select options={field.valueEnum} {...field.searchProps} />
        ) : null;
      case 'treeSelect':
        return <TreeSelect {...field.searchProps} />;
      case 'date':
        return <DatePicker {...field.searchProps} />;
      case 'dateRange':
        return <DateRangePicker {...field.searchProps} />;
      case 'cascader':
        return <Cascader {...field.searchProps} />;
      default:
        return <Input {...field.searchProps} />;
    }
  };

  // 实际渲染字段
  const renderFields = (data: IField[]) => {
    return data
      .sort((a, b) => (b.order || 0) - (a.order || 0))
      .map((item, index) => ({
        ...item,
        show: index < LINE_COUNT || !collapsed,
      }));
  };

  // 搜索
  const search = () => {
    const values = form.getFieldsValue();
    onSearch && onSearch(values);
  };

  // 重置
  const reset = () => {
    form.resetFields();
    onReset && onReset();
  };

  if (!(fields instanceof Array && fields.length)) return null;

  return (
    <div
      className={classnames(
        'uniubi-table-filter',
        collapsed
          ? 'uniubi-table-filter-collapsed'
          : 'uniubi-table-filter-expanded',
        `uniubi-table-filter-${mode}`,
        className,
      )}
      style={style}
    >
      <Form
        className="uniubi-table-filter-form"
        layout="vertical"
        form={form}
        {...formProps}
      >
        <Row gutter={GUTTER}>
          {renderFields(fields).map(filed => {
            const {
              valueEnum,
              valueType,
              searchProps,
              order,
              show,
              ...rest
            } = filed;
            return (
              <Col
                span={SPAN}
                key={filed.name}
                style={{ display: filed.show ? 'block' : 'none' }}
              >
                <Form.Item {...rest}>{matchItem(filed)}</Form.Item>
              </Col>
            );
          })}
          <Col span={SPAN} key="actions">
            <Form.Item
              label=" "
              noStyle={
                renderFields(fields).filter(item => item.show).length %
                  (LINE_COUNT + 1) ===
                0
              }
            >
              <Space>
                <Button
                  className="uniubi-table-filter-btn"
                  type="primary"
                  onClick={search}
                >
                  搜索
                </Button>
                <Button className="uniubi-table-filter-btn" onClick={reset}>
                  重置
                </Button>
                {needCollapsedButton && (
                  <Button
                    icon={
                      collapsed ? <DownOutlined /> : <UpOutlined />
                    }
                    onClick={() => {
                      setCollapsed(!collapsed);
                    }}
                  />
                )}
              </Space>
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </div>
  );
};

export default TableFilter;
